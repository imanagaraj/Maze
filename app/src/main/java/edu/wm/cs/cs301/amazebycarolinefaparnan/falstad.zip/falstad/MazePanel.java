//package edu.wm.cs.cs301.amazebycarolineaparna.falstad;
//
//
//import java.awt.Color;
//
//import java.awt.Font;
//import java.awt.FontMetrics;
//import java.awt.Graphics;
//
//import java.awt.Image;
//import java.awt.Panel;
//import java.awt.Point;
//import java.awt.RenderingHints;
//import java.awt.RenderingHints.Key;
//
///**
// * Add functionality for double buffering to an AWT Panel class.
// * Used for drawing a maze.
// *
// * @author pk
// *
// */
//public class MazePanel extends Panel  {
//	/* Panel operates a double buffer see
//	 * http://www.codeproject.com/Articles/2136/Double-buffer-in-standard-Java-AWT
//	 * for details
//	 */
//	private Image bufferImage ;
//	public Graphics gc;
//
//	Point point;
//	MazeController maze;
//	Color color;
//	RenderingHints hint;
//
//	Font largeBannerFont = new Font("TimesRoman", Font.BOLD, 48);
//    Font midBannerFont = new Font("TimesRoman", Font.BOLD, 16);
//    Font smallBannerFont = new Font("TimesRoman", Font.BOLD, 12);
//
//    /**
//	 * Constructor. Object is not focusable.
//	 */
//	public MazePanel() {
//		super() ;
//		this.setFocusable(false) ;
//		//Graphics temp = getBufferGraphics();
//		//gc = temp;
//	}
//
//	@Override
//	public void update(Graphics gc) {
//		paint(gc) ;
//	}
//	public void update() {
//		paint(getGraphics()) ;
//	}
//
//
//	/**
//	 * Draws the buffer image to the given graphics object.
//	 * This method is called when this panel should redraw itself.
//	 */
//	@Override
//	public void paint(Graphics gc) {
//		if (null == gc) {
//			System.out.println("MazePanel.paint: no graphics object, skipping drawImage operation") ;
//		}
//		else {
//			gc.drawImage(bufferImage,0,0,null) ;
//		}
//	}
//
//	public void initBufferImage() {
//		bufferImage = createImage(Constants.VIEW_WIDTH, Constants.VIEW_HEIGHT);
//		if (null == bufferImage)
//		{
//			System.out.println("Error: creation of buffered image failed, presumedly container not displayable");
//		}
//		gc = this.getBufferGraphics();
//	}
//	/**
//	 * Obtains a graphics object that can be used for drawing.
//	 * Multiple calls to the method will return the same graphics object
//	 * such that drawing operations can be performed in a piecemeal manner
//	 * and accumulate. To make the drawing visible on screen, one
//	 * needs to trigger a call of the paint method, which happens
//	 * when calling the update method.
//	 * @return graphics object to draw on
//	 */
//	public Graphics getBufferGraphics() {
//		if (null == bufferImage)
//			initBufferImage() ;
//		if (null == bufferImage)
//			return null ;
//		return bufferImage.getGraphics() ;
//	}
//
//
////	public MazePanel(MazeController maze){
////		this.maze = maze;
////		this.gc = maze.panel.getBufferGraphics();
////	}
////
////	/**
////	 *
////	 * Used in First Person Drawer and RangeSet
////	 */
////
////	public void setRenderingHint(Key hintKey, Object hintValue){
////		hint = new RenderingHints(hintKey,hintValue);
////	}
////
////	public Point getPoint(){
////		return point;
////	}
////
////	/**
////	 * Used in First Person Drawer and RangeSet
////	 * set the point with a point object
////	 */
////	public void setPoint( int x, int y){
////
////		point = new Point(x, y);
////	}
////
////	public Graphics getGraphics(){
////		return gc;
////	}
////
////	public void setGraphics(Object gc){
////		gc = (Graphics) gc;
////	}
////
////	/**
////	 * setting color useful for seg
////	 * @param color
////	 */
////	public void setColor(int color){
////		this.color = new Color(color);
////	}
////
////	public void setColor(int color1, int color2, int color3){
////		this.color = new Color(color1, color2, color3);
////	}
////
////	/**
////	 * to use in seg
////	 * @param name of color
////	 */
////	public void setGraphicsColor(String name){
////
////		//this.gc = getBufferGraphics();
////		switch(name){
////		case "red":
////			gc.setColor(Color.red);
////			break;
////		case "gray":
////			gc.setColor(Color.gray);
////			break;
////		case "yellow":
////			gc.setColor(Color.yellow);
////			break;
////		case "white":
////			gc.setColor(Color.white);
////			break;
////		case "black":
////			gc.setColor(Color.black);
////			break;
////		case "blue":
////			gc.setColor(Color.blue);
////			break;
////		case "orange":
////			gc.setColor(Color.orange);
////			break;
////		case "darkGray":
////			gc.setColor(Color.darkGray);
////			break;
////		case "pink":
////			gc.setColor(Color.pink);
////			break;
////		case "cyan":
////			gc.setColor(Color.cyan);
////			break;
////		}
////
////	}
////
////	public Color getColor(){
////		return color;
////	}
////
////    public void setGraphicsFont(String name) {
////        switch (name) {
////        case "large":
////                   gc.setFont(largeBannerFont);
////                   break;
////
////        case "mid":
////                   gc.setFont(midBannerFont);
////                   break;
////        case "small":
////                   gc.setFont(smallBannerFont);
////                   break;
////        }
////}
////
////public void centerString(FontMetrics fm, String str, int ypos) {
////	//this.gc = getBufferGraphics();
////        gc.drawString(str, (Constants.VIEW_WIDTH - fm.stringWidth(str)) / 2, ypos);
////}
////
////public FontMetrics getFontMetrics(){
////	//this.gc = getBufferGraphics();
////    FontMetrics fm = gc.getFontMetrics();
////    return fm;
////}
////
////public void fillRect(int i, int j, int viewWidth, int viewHeight) {
////	gc.fillRect(i, j, viewWidth, viewHeight);
////
////}
//
//}
