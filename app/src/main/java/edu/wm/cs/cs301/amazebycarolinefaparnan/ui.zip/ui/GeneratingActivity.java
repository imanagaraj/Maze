package edu.wm.cs.cs301.amazebycarolinefaparnan.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import edu.wm.cs.cs301.amazebycarolinefaparnan.R;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.os.Handler;

import android.view.KeyEvent;

/**
 * Class: GeneratingActivity
 * Responsibility: Show this screen while the maze is being generated and display the generation progress on screen
 * Collaborators: AMazeActivity
 *
 * @author Caroline Fagan and Aparna Nagaraj
 */


public class GeneratingActivity extends AppCompatActivity {

    private ProgressBar progress;
    private int progressVal = 0;
    private TextView percentage;
    private boolean increasing;
    private Handler handlerProg = new Handler();
    private int status;
    //private int percentage;

    public String algorithm;
    public int level;
    public String robot;

    Singleton singleton;

    /**
     * Creates the progress bar to inform the user of how much of the maze has been generated
     * and switches to the generating screen when finished.
     * @param circle
     */
    @Override
    protected void onCreate(Bundle circle) {
        super.onCreate(circle);
        setContentView(R.layout.activity_generating);

        progress = (ProgressBar) findViewById(R.id.generatingprog);
        assert progress != null;
        percentage = (TextView) findViewById(R.id.percentage);

        status = 0;

        singleton = new Singleton();
        singleton.getApplicationContext();

        // Retrieve user input from AMazeActivity and use to set up our maze controller
        Intent past = getIntent();
        final String ALGORITHM = past.getStringExtra("alg");
        final String DRIVER = past.getStringExtra("robot");
        int skill = past.getIntExtra("level", 0);

        singleton.getMaze().setMaze(DRIVER, ALGORITHM, skill);
        singleton.getMaze().init();

        // Continue to pass information into the next activity
        final Intent toPlay = new Intent(this, PlayActivity.class);
        toPlay.putExtra("alg", ALGORITHM);
        toPlay.putExtra("robot", DRIVER);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (status < 100) {
                    status++;
                    handlerProg.post(new Runnable() {
                        @Override
                        public void run() {
                            progress.setProgress(status);
                            percentage.setText("Progress: " + status + "% completed");
                        }
                    });

                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                //switch to the play activity
               startActivity(toPlay);
            }
        }).start();


    }

    /**
     * Return the user to AMazeActivity
     */
    @Override
    public void onBackPressed(){
        this.startActivity(new Intent(GeneratingActivity.this, AMazeActivity.class));

    }
}
