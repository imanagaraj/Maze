package edu.wm.cs.cs301.amazebycarolinefaparnan.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import edu.wm.cs.cs301.amazebycarolinefaparnan.R;
/**
 * Class: FinishActivity
 * Responsibility: Shows the user a message based on whether the game was won or lost. Option to play again.
 * Collaborators: PlayActivity
 *
 * @author Caroline Fagan and Aparna Nagaraj
 */
public class FinishActivity extends AppCompatActivity {

    Button playAgain;
    TextView winner;
    TextView failed;

    /**
     * Show the win/lose message and create the button to return to the start screen if selected
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);

        winner = (TextView) findViewById(R.id.solvedCongrats);

        winner.setVisibility(winner.VISIBLE);

        //Play again button and listener, returns to the start screen if pressed
        playAgain = (Button) findViewById(R.id.restart);
        playAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Going back to start screen", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(FinishActivity.this, AMazeActivity.class);

                startActivity(i);
                finish();
                Log.v("Title: revisit button", "load an old maze");

            }
        });
    }

    /**
     * Return the user to AMazeActivity
     */
    @Override
    public void onBackPressed(){
        this.startActivity(new Intent(FinishActivity.this, AMazeActivity.class));

    }

}
