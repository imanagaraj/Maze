package edu.wm.cs.cs301.amazebycarolinefaparnan.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.ToggleButton;
import android.widget.Toast;
import android.util.Log;
import android.os.Handler;


import edu.wm.cs.cs301.amazebycarolinefaparnan.R;

/**
 * Class: PlayActivity
 * Responsibility: Show the user the maze and provide controls to navigate with a manual driver or
 * pause/continue with an automatic driver. Give the options of showing a maze preview, solution, and walls.
 * Collaborators: GeneratingActivity
 *
 * @author Caroline Fagan and Aparna Nagaraj
 */

public class PlayActivity extends AppCompatActivity {

    Button start;
    Button pause;
    ImageButton up;
    ImageButton down;
    ImageButton right;
    ImageButton left;
    ToggleButton showMaze;
    ToggleButton showSolution;
    ToggleButton showWalls;
    static ProgressBar energy;
    Button toFin;

    static Singleton singleton;

    Handler runHandle = new Handler();

    /**
     * update the robot's energy
     */
    static Handler progressHandler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            energy.setProgress(100);
            //change this to update from maze controller with energy consumed
        }
    };

    /**
     * Create the toggle buttons, navigation buttons, and progress bar. Toggle buttons turn hints on
     * and off. Navigation buttons allow the user to manually navigate the maze. Switches to the
     * finish screen when the robot runs out of energy or the maze is finished.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        energy = (ProgressBar) findViewById(R.id.energyBar);




      //  final Bundle robot = getIntent().getExtras().getBundle("robot");
        Intent genIntent = getIntent();
        String robotVal = genIntent.getStringExtra("robot");
        String algorithm = genIntent.getStringExtra("alg");
             //   robot.getString("robot");

        // pause button and listener to pause automatic driver
        pause = (Button) findViewById(R.id.pause);
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Pausing", Toast.LENGTH_SHORT).show();
                Log.v("Title: pause button", "pausing driver");
                // add click listener items to pause the maze when drivers are integrated
            }
        });

        //start button and listener to start automatic listener
        start = (Button) findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Starting", Toast.LENGTH_SHORT).show();
                Log.v("Title: start button", "starting/resuming driver");
            }
        });

        // up button and listener to manually driver robot forward
        up = (ImageButton) findViewById(R.id.forward);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("Title: up arrow", "moved forward");
                //set the up arrow equal to the key down method for up in the maze
            }
        });

        //down button and listener to manually turn the robot around
        down = (ImageButton) findViewById(R.id.down);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("Title: down arrow", "turn around"); // ?????
                //set the up arrow equal to the key down method for down in the maze
            }
        });

        // right button and listener to manually turn the robot right
        right = (ImageButton) findViewById(R.id.right);
        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("Title: right arrow", "turn right");
                //set the up arrow equal to the key down method for right in the maze
            }
        });

        //left button and listener to manually turn the robot left
        left = (ImageButton) findViewById(R.id.left);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("Title: left arrow", "turn left");
                //set the up arrow equal to the key down method for left in the maze
            }
        });

        //show the maze preview if the user selects
        showMaze = (ToggleButton) findViewById(R.id.showMaze);
        showMaze.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView , boolean isSelected) {
                if (isSelected) {
                    Log.v("Title: show maze on", "show maze preview");
                    // turn preview to true in maze application
                } else {

                }
            }
        });

        //show the solution to the maze if the user selects
        showSolution = (ToggleButton) findViewById(R.id.showSolution);
        showSolution.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView , boolean isSelected) {
                if (isSelected) {
                    Log.v("Title: show solution on", "show solution ");
                    // turn solution to true in maze application
                } else {

                }
            }
        });

        //show the maze walls in the preview if the user selects
        showWalls = (ToggleButton) findViewById(R.id.showWall);
        showWalls.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView , boolean isSelected) {
                if (isSelected) {
                    Log.v("Title: show walls on", "show walls ");
                    // turn show walls to true in maze application
                } else {

                }
            }
        });

        // show the appropriate buttons based on the driver type
        if(robotVal.equals("Manual Driver")){
            up.setVisibility(up.VISIBLE);
            down.setVisibility(down.VISIBLE);
            right.setVisibility(right.VISIBLE);
            left.setVisibility(left.VISIBLE);
        }

        else{
            start.setVisibility(start.VISIBLE);
            pause.setVisibility(pause.VISIBLE);

        }


        //intermediate continue button to continue to the finish state
        toFin = (Button) findViewById(R.id.goFinish);
        toFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlayActivity.this, FinishActivity.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(),"Continuing to Finish Screen", Toast.LENGTH_SHORT ).show();
                Log.v("Title: Continue Button", "continue button pressed");

            }
        });

//        runHandle.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                Intent intent = new Intent(PlayActivity.this, FinishActivity.class);
//                startActivity(intent);
//            }
//        }, 5000);

    }

    /**
     * Return the user to AMazeActivity
     */
    @Override
    public void onBackPressed(){
        this.startActivity(new Intent(PlayActivity.this, AMazeActivity.class));

    }

}
