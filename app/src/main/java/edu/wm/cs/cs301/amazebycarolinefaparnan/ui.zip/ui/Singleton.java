package edu.wm.cs.cs301.amazebycarolinefaparnan.ui;

import android.app.Activity;
import android.app.Application;
import android.support.v7.app.AppCompatActivity;

import edu.wm.cs.cs301.amazebycarolinefaparnan.falstad.MazeController;

/**
 * Created by Caroline and Aparna on 11/20/2016.
 */
public class Singleton extends Application {

    public MazeController maze;

    @Override
    public void onCreate() {
        super.onCreate();
        maze = new MazeController();
    }

    public MazeController getMaze() {
        return maze;
    }
}
